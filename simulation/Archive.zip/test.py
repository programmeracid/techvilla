x = 1
y = x
print(y)
x = 0
print(y)